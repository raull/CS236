/*
 * DatalogProgram.cpp
 *
 *  Created on: Feb 21, 2014
 *      Author: raull
 */

#include "DatalogProgram.h"

DatalogProgram::DatalogProgram() {
	// TODO Auto-generated constructor stub

}

DatalogProgram::~DatalogProgram() {
	// TODO Auto-generated destructor stub
}

