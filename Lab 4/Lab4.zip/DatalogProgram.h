/*
 * DatalogProgram.h
 *
 *  Created on: Feb 21, 2014
 *      Author: raull
 */

#ifndef DATALOGPROGRAM_H_
#define DATALOGPROGRAM_H_

class DatalogProgram {
public:
	DatalogProgram();
	virtual ~DatalogProgram();
};

#endif /* DATALOGPROGRAM_H_ */
