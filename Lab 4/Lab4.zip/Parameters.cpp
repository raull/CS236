/*
 * Parameters.cpp
 *
 *  Created on: Feb 21, 2014
 *      Author: raull
 */

#include "Parameters.h"

Parameters::Parameters() {
	// TODO Auto-generated constructor stub

}

Parameters::~Parameters() {
	// TODO Auto-generated destructor stub
}

