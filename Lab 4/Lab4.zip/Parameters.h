/*
 * Parameters.h
 *
 *  Created on: Feb 21, 2014
 *      Author: raull
 */

#ifndef PARAMETERS_H_
#define PARAMETERS_H_

class Parameters {
public:
	Parameters();
	virtual ~Parameters();
};

#endif /* PARAMETERS_H_ */
